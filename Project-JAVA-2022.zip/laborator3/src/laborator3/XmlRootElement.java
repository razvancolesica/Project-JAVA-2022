package laborator3;

public @interface XmlRootElement {
}
