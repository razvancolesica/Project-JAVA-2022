package laborator3;

public @interface XmlElement {
}
