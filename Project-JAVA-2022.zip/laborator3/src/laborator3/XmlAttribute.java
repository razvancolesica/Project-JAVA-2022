package laborator3;

public @interface XmlAttribute {
}
